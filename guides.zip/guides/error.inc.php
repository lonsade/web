<?php
	switch ($type_error) {
		case 1:
			$ready_title = 'Страница не существует';
			echo '<p>Страница не существует, ошибка в <span>'.$project[0].'</span></p>';
			break;
		case 2:
			$ready_title = 'Герой не существует';
			echo '<p>Такого героя не существует, ошибка в <span>'.$project[1].'</span></p>';
			break;
	}
	$error = true;
?>