<?php
	$arr_guides = getGuides();
?>
<div class="contentAllGuides">
	<div id="commonTitles">
		<span>Герой</span>
		<span>Название</span>
		<span>Автор</span>
		<span>Дата</span>
		<span>Рейтинг</span>
		<span>Просмотры</span>
	</div>
	<?php
if (!empty($arr_guides)){
foreach($arr_guides as $guid){
$dt = date("d.m.y", $guid['dt']);
$name = upData($guid['name']);
$rating = ($guid['n_rating'] != 0) ? $guid['rating'] / $guid['n_rating'] : 0;
echo <<<GUIDES
		<div class="guide" id="guid_{$guid['id']}">
			<span id="hero">{$guid['hero']}</span>
			<span id="name">$name</span>
			<span id="author"><a href="#">{$guid['author']}</a></span>
			<span id="date">$dt</span>
			<span id="rating" title="{$guid['n_rating']} оценок">
				<span class="stars_show"></span>
				<span class="stars_active" style="width: {$rating}px;"></span>
			</span>
			<span id="looks">{$guid['looks']}</span>
		</div>
GUIDES;
}		
}
	?>
</div>
<script type="text/javascript" src="templates/all/js/creating.js"></script>