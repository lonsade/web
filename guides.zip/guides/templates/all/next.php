<?php
	if(!$_COOKIE['look'.$id] && !$_COOKIE['login']){
		setcookie('look'.$id, true,  time()+60*60*24*30);
		ableForLook($id, true);
	}else{
		ableForLook($id, false);
	}
	$arr_guid = getGuid($id);
	$arr_about_hero = getHeroInfo($arr_guid[0]['hero']);
	$dt = date("d.m.y H:i", $arr_guid[0]['dt']);
	$levels = explode('-', $arr_guid[0]['lvls']);
	$skills = getSkills($arr_guid[0]['hero']);
	$titles = explode('-', $arr_guid[0]['titles']);
?>

<div id="personalGuid" name="<?=$id?>">
	<div class="g-information">
		<p>
		<?php
			if(ableforvoice($_COOKIE['login'], $id)){
		?>
			<span id="rating">
				<span class="star"></span>
				<span class="star"></span>
				<span class="star"></span>
				<span class="star"></span>
				<span class="star"></span>
			</span>
			<span id="lookrating" style="display: none;">
				<span class="stars_show"></span>
				<span class="stars_active"></span>
			</span>
		<?php
			}else{
		?>
			<span id="lookrating" title="Вы уже голосовали">
				<span class="stars_show"></span>
				<span class="stars_active" style="width: <?=($arr_guid[0]['n_rating'] != 0) ? $arr_guid[0]['rating'] / $arr_guid[0]['n_rating'] : 0?>px;"></span>
			</span>
		<?php
			}
		?>
			<span title="Название гайда" class="name __title"><?=$arr_guid[0]['name']?></span>
			<span> от </span>
			<span class="author __title" title="Перейти к профилю автора">
				<a href="#"><?=$arr_guid[0]['author']?></a>
			</span>
			<span class="dt"><?=$dt?></span>
		</p>
	</div>
	<div class="guidInfo">
		<div class="top">
			<div class="info">
				
			</div>
			<div class="image">
				<p><?=$arr_guid[0]['hero']?></p>
				<img src="<?=$arr_about_hero[0]['image']?>" alt="<?=$arr_guid[0]['hero']?>"/>
			</div>
		</div>
		<div class="description">
			<div class="headerOfcontent"><span>Введение</span><div class="hideOrShow"></div></div>
			<div class="content-info">
				<div class="info"><?=$arr_guid[0]['information']?></div>
			</div>
		</div>
		<div class="centre">
			<div class="headerOfcontent"><span>Комментарии к скилам</span><div class="hideOrShow"></div></div>
			<div class="content-info">
			<?php
				$num = 1;
				foreach($skills as $skill){
					echo '<div class="skillImg"><img src="'.$skill['img'].'"/><div class="text-helper">Информация по использованию <span style="color: #e8a902;text-transform: uppercase;">'.$skill['name'].'</span></div><p>'.$arr_guid[0]['s'.$num++].'</p></div>';
				}
			?>
			</div>
		</div>
		<div class="skillbuild">
			<div class="headerOfcontent"><span>Скиллбилд</span><div class="hideOrShow"></div></div>
			<div class="content-info">
				<div>
					<div class="c-skills">
						<?php
							foreach($skills as $skill){
								echo '<img class="skills-h" src="'.$skill['img'].'" alt="'.$skill['name'].'"/>'.getHideSkillInfo($skill['name'], $arr_guid[0]['hero']);
							}
						?>
						<img src="http://localhost/guides/images/resources/plus_dota.png"/>
					</div>
					<div class="c-levels">
						<?php
							$count = 1;
							for($i = 1; $i < 6; $i++){
								echo '<div>';
								for($c = 1; $c < 26; $c++){
									if(in_array($count, $levels)){
										echo '<div id="lvl_'.$count.'" class="levels active-level"><p>'.$c.'</p></div>';
									}else{
										echo '<div id="lvl_'.$count.'" class="levels"></div>';
									}
									$count++;
								}
								echo '</div>';
							}
						?>
					</div>
				</div>
			</div>
		</div>
		<div class="content-m">
			<div class="headerOfcontent"><span>Итембилд</span><div class="hideOrShow"></div></div>
			<div class="content-info">
			<?php
				$str = explode('-', $arr_guid[0]['items']);
				$str1 = array();
				foreach($str as $url){
					$s = explode('@', $url);
					$str1[$s[0]] = $s[1];
				}
				end($str1);
				$row = (key($str1) < 57)?5:6;
				for($r = 1; $r < $row; $r++){
					echo '<div style="overflow: visible !important;" id="_'.''.'" class="contentForItems">';
					$title = ($titles[$r-1] == 'Добавить')? 'Дополнительно': $titles[$r-1];
					echo '<div class="title">'.$title.'</div>';
					for($c = 1; $c < 15; $c++){
						$url = $str1[($r-1)*14 + $c];
						if($url){
							echo '<div class="contentForItem active-contentItem"><div class="pickedItems"><div class="showHelp"></div><img src="'.$url.'"/></div>'.getHideItemInfo($url).'</div>';
						}else{
							echo '<div class="contentForItem"></div>';
						}
					}
					echo '</div>';
				}
			?>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="templates/all/js/creating.js"></script>