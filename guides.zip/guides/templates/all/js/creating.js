$('.hideOrShow').toggle(function(){
	var hidden = $(this).parent().next();
	hidden.stop();
	if(!$(this).data('height')){
		$(this).data({'height': hidden.height()});
	}
	$(this).addClass('hideOrShow-active');
	hidden.animate({opacity: 0}, 300, function(){
		hidden.addClass('hidden-helper').animate({height: 0}, 300, function(){
			hidden.children().css({display: 'none'});
		});
	});
},function(){
	var hidden = $(this).parent().next();
	hidden.stop();
	$(this).removeClass('hideOrShow-active');
	hidden.animate({height: $(this).data('height') + 'px'}, 300, function(){
		hidden.children().css({display: 'block'});
		hidden.removeClass('hidden-helper').animate({opacity: 1}, 300);
	});
});
var personalGuid = $('#personalGuid');
var stars = $('#rating .star');

stars.hover(function(){
	stars.slice(0, $(this).index()+1).addClass('starsactive');
},function(){
	stars.removeClass('starsactive');
});

stars.click(function(){
	var rating = ($(this).index()+1) * 22;
	$.ajax({
		type: 'POST',
		url: 'includes/all/rating.php',
		data: 'star=' + rating + '&guid=' + personalGuid.attr('name'),
		success: function(msg){
			if(msg == 0){
				getError('Войдите или зарегистрируйтесь, чтобы проголосовать.');
			}else{
				stars.unbind();
				stars.parent().hide().next().show().children('.stars_active').css({width: msg+'px'});
			}
		}
	});
});