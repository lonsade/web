<?php
	session_start();
	require "../../query.inc.php";
	require "../../labs.inc.php";
	
	print_r($_POST());
?>