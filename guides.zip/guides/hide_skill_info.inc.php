<?php
$text_info = explode('&', $skill['text_info']);
$int_info = explode('&', $skill['int_info']);
?>

<div class="skill_helper">
	<div class="shower"></div>
	<div class="name"><?=$skill['title']?></div>
	<hr>
	<div class="type">
		<?foreach($text_info as $info):?>
		<p><?=$info?></p>
		<?endforeach;?>
	</div>
	<hr>
	<div class="bio"><?=$skill['about']?></div>
	<hr>
	<div class="other">
		<?foreach($int_info as $info):?>
		<p><?=$info?></p>
		<?endforeach;?>
	</div>
	<?if(!empty($skill['cooldown']) and !empty($skill['manacost'])):?>
	<hr>
	<div class="cdmp">
		<?if(!empty($skill['cooldown'])):?>
		<div style="float: left;">
			<div class="cdmpimgs"></div>
			<span><?=$skill['cooldown']?></span>
		</div>
		<?endif;?>
		<?if(!empty($skill['manacost'])):?>
		<div style="float: right;">
			<div class="mp cdmpimgs"></div>
			<span><?=$skill['manacost']?></span>
		</div>
		<?endif;?>
	</div>
	<?endif;?>
</div>