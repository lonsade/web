//Глобальные переменные, необходимые для работы скрипта
var enter_under_error;
var content = $('.wrap > .content');
var links = $('menu .links');
var pointer = $('#pointer');
//Функция перенаправления без перезагрузки страницы
function doRedirect(hash){
	//Курсор на самый вверх
	$(document).scrollTop(0);
	//Установка главной страницы
	if(!hash)
		hash = '#all';
	//Установка загрузучного титла
	document.title = 'В процессе...';
	links.removeClass('active');
	pointer.hide();
	content.animate({opacity: 0}, 300).slideUp(300,function(){
		content.load('handler.php', {hash: hash}, function(responseText){
			$(responseText).ready(function(){
				content.slideDown(300).animate({opacity: 1}, 300, function(){
					document.title = ready_title;
					if (!error){
						pointer.show();
						cur_link = links.filter('#'+ready_project).addClass('active');
						pointer.css({left: Math.ceil((cur_link.innerWidth() - 45) / 2 + cur_link.position().left) + 'px'}).show();
					}
				});
			});
		});
	});
}
//Вызов редиректа для первого раза(для нового хеша)
doRedirect(location.hash);
//Вызов редиректа по нажатию ссылок навигации
links.click(function(){
	location.hash = $(this).attr('id');
});
//Функция для отловки смены хеша(основа работы скрипта)
$(window).bind('hashchange', function(){
	doRedirect(location.hash);
});
/*
//Всплывающая подсказка
function showHelp(object, align){
	var documentHeight = $(document).height();
	var documentWidth = $(document).width();
	object.show().css({opacity: 0});
	//Выравнивание подсказки относительно краев документа(если необходимо)
	if(align){
		var shower = object.find('.shower');
		if(!object.data('top')){
			object.data({top: parseInt(object.css('margin-top'))});
			shower.data({top: parseInt(shower.css('margin-top'))});
		}
		var height = object.outerHeight();
		var width = object.outerWidth();
		var left = object.offset().left;
		var top = object.offset().top;
		//По ширине
		if((documentWidth - left - width) < 0){
			object.css({'margin-left': -15 - width + 'px'});
			shower.addClass('shower-right');
		}
		//По высоте
		if((documentHeight - top - height) < 0){
			object.css({'margin-top': object.data('top') + (documentHeight - top - height - 5) + 'px'});
			shower.css({'margin-top': -(documentHeight - top - height - 5) + 'px'});
		}
	}
	object.css({opacity: 1});
}
//Удаление подсказки
function hideHelp(object){
	var shower = object.find('.shower');
	object.css({'margin-top': object.data('top') + 'px'});
	shower.css({'margin-top': shower.data('top') + 'px'});
	object.hide();
}
//Функция для плавного исчезновения блока с регистрацией
function transition(msg){
	login = msg;
	registration.animate({'margin-top': '-' + (registration.innerHeight() + 8) + 'px'}, 300, function(){
		underpanel.empty();
		admin.animate({opacity: 0}, 300, function(){
			$(this).children('#reg_or_enter').empty().append('<span class="profile">Добро пожаловать, <span>'+msg+'</span></span><input id="exist" type="button" title="Выход"/>');
			$(this).animate({opacity: 1}, 300);
			links.filter('#all').before('<div class="links" id="creating"><p>Создать гайд</p></div>').after('<div class="links" id="my"><p>Мои гайды</p></div>');
			pointer.css({left: Math.ceil((links.filter('.active').innerWidth() - 45) / 2) + links.filter('.active').position().left + 'px'}).show();
			links = $('.links');
			if(enter_under_error){
				location.hash = 'my';
			}
		});
	});
}
function getError(msg){
	var block = error.children('.block');
	block.find('.content-styles').html(msg);
	error.children('.screen').height($(document).height()).show();
	block.css({left: ($(document).width() - block.width())/2, top: ($(window).height() - block.height())/2}).fadeIn(300);
}
error.find('.close').click(function(){
	error.children('.block').fadeOut(300, function(){
		error.children('.screen').removeAttr('style');
		$(this).removeAttr('style');
	})
});
//Клик на кнопку регистрации
panel.on('click', '#sendReg', function(){
	$.ajax({
		type: 'POST',
		url: 'registration.php',
		data: 'login=' + registration.find('#regLogin').val() + '&pass=' + registration.find('#regPassword').val(),
		success: function(msg){
			if(msg.length <= 15){
				transition(msg);
			}else{
				getError(msg);
			}
		}
	});
});
//Клик на кнопку выхода
panel.on('click', '#exist', function(){
	$.ajax({
		url: 'exist.php',
		success: function(){
			login = '';
			underpanel.append(registration_HTML);
			registration = $('.registration');
			admin.animate({opacity: 0}, 300, function(){
				$(this).empty().append('<div id="reg_or_enter"><span name="sendReg" alt="Создать">Регистрация</span><span id="border"></span><span name="enter" alt="Войти">Войти</span></div>');
				$(this).animate({opacity: 1}, 300);
				links.filter('#all').next().remove();
				links.filter('#all').prev().remove();
				links = $('.links');
				location.hash = 'all';
				var cur_link = links.filter('.active');
				pointer.css({left: Math.ceil((cur_link.innerWidth() - 45) / 2) + cur_link.position().left + 'px'});
			});
		}
	});
});
//Переключатель между входом и регистрацией
panel.on('click', '#reg_or_enter span[name]', function(){
	registration.stop();
	var the = $(this);
	var time = 300;
	$(this).siblings().removeAttr('style');
	if(registration.css('margin-top') == '-' + (registration.innerHeight() + 8) + 'px'){
		time = 0;
	}
	registration.animate({'margin-top': '-' + (registration.innerHeight() + 8) + 'px'}, time, function(){
		if(the.attr('alt') == 'Войти'){
			registration.find('#label-remember').show();
		}else{
			registration.find('#label-remember').hide();
		}
		if(the.attr('style')){
			the.removeAttr('style');
		}else{
			the.css({color: '#e8a902'});
			registration.find(':submit').attr('id', the.attr('name'));
			registration.animate({'margin-top': '-8px'}, 300);
		}
	});
});





//Клик на кнопку входа
panel.on('click', '#enter', function(){
	var remember = ($(this).siblings('#checkbox-remember').is(':checked'))? 1: 0;
	$.ajax({
		type: 'POST',
		url: 'enter.php',
		data: 'login=' + registration.find('#regLogin').val() + '&pass=' + registration.find('#regPassword').val() + '&remember=' + remember,
		success: function(msg){
			if(msg != 0){
				//Все правильно
				transition(msg);
			}else{
				//Неправильно введены данные
				getError('Логин или пароль неверны');
			}
		}
	});
});
*/

/* $('.links p').mouseenter(function(e){
	var link = $(this).parent();
	var content = link.innerWidth();
	var left = link.position().left;
	var width = 45;
	var cur_left = Math.ceil((content - width) / 2) + left + 'px';
	if(!pointer.data('left')){
		pointer.data('left', pointer.css('left'))
	}
	pointer.animate({left: cur_left}, 200, 'linear');
}); */