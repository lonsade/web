<?php
	require "query.inc.php";
	require "labs.inc.php";	
	define("USER_NAME", $_COOKIE['login']);
?>

<!DOCTYPE>

<html>
	<head>
		<title>В процессе...</title>
		<meta charset="utf-8">
		<script type="text/javascript" src="js/jquery-3.0.0.min.js"></script>
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>
		<script type="text/javascript">
			var login = '<?php echo (USER_NAME)?USER_NAME:'';?>';
		</script>
		<link type="text/css" rel="StyleSheet" href="css/creating.css.php">
		<link rel="stylesheet" type="text/css" href="css/styles.css">
	</head>
	
	<body>
		<?include('dom/header.inc.php');?>
		<div class="wrap box_shadow">
			<?include('dom/menu.inc.php');?>
			<?include('dom/content.inc.php');?>
			<?include('dom/footer.inc.php');?>
		</div>
		<script type="text/javascript" src="js/guides.js"></script>
	</body>
</html>