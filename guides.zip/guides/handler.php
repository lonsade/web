<?php
	session_start();
	if (!isset($_POST['hash']))
		exit(0);
	require "query.inc.php";
	require "labs.inc.php";
	$progects = get_progects();

	$titles = get_titles();

	$address = substr($_POST['hash'], 1);
	$project = explode('>', $address);

	$error = false;
	if (!isset($progects[$project[0]])){
		$type_error = 1;
		include 'error.inc.php';
	}
	else{
		$ready_title = $titles[$project[0]];
		if (isset($project[1])){

			$heroes = get_heroes_list();
			if (!in_array($project[1], $heroes)){
				$type_error = 2;
				include 'error.inc.php';
			}
			else{
				$id = $project[1];
				include 'templates/'.$project[0].'/next.php';
				$ready_title .= ' на '.$project[1];
			}
		}
		else
			include 'templates/'.$project[0].'/index.php';
	}
?>
<script type="text/javascript">
	<?if(!$error):?>
	ready_project = '<?=$project[0]?>';
	<?endif;?>
	ready_title = '<?=$ready_title?>';
	error = '<?=$error?>';
</script>