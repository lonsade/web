<?php
	setcookie('login', '');
?>