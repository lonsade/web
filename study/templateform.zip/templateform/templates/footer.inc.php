<footer>
	<span>Все права защищены</span>
	<span>Всі права захищені</span>
	<span>All rights reserved</span>
	<span>Todos los derechos reservados</span>
	<span>Alle Rechte vorbehalten</span>
	<span>保留所有權利。</span>
	<span>by Lonsade</span>
</footer>