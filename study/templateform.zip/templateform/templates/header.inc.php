<header>
    <div><?=$header?></div>
</header>